# Trino Connector for Power BI

Connecteur Power BI custom pour Trino avec support DirectQuery et impersonation utilisateur.

## Fonctionnalités

- **DirectQuery** : Requêtes en temps réel sans import de données
- **Impersonation** : Propagation de l'identité utilisateur vers Trino via `DelegationUID`
- **Multi-authentification** : Implicit (DSN), Username/Password, Windows
- **Gateway** : Compatible avec Power BI Gateway pour le refresh automatique

## Prérequis

1. **Driver ODBC Simba Trino** installé et configuré
2. **DSN ODBC** configuré dans Windows (panneau de configuration ODBC)
3. **Power BI Desktop** avec connecteurs custom activés

## Installation

### Build

```
VS Code: Ctrl+Shift+P → "Power Query: Build project"
```

Le fichier `TrinoConnector.mez` sera généré dans `bin/AnyCPU/Debug/`.

### Déploiement

1. Copier `TrinoConnector.mez` vers :
   ```
   Documents\Power BI Desktop\Custom Connectors\
   ```

2. Activer les connecteurs custom dans Power BI Desktop :
   - Fichier → Options → Sécurité
   - Cocher "Autoriser le chargement des extensions..."

3. Redémarrer Power BI Desktop

## Utilisation

1. **Get Data** → **Database** → **Trino (DirectQuery)**
2. Entrer le nom du DSN ODBC
3. Optionnel : Spécifier le catalog Trino
4. Choisir le mode d'authentification :
   - **Use DSN Configuration** : Utilise les credentials du DSN
   - **Username/Password** : Entre les credentials avec impersonation
   - **Windows** : Utilise l'authentification Windows

## Configuration du DSN

Le DSN ODBC doit être configuré avec les paramètres suivants :

| Paramètre | Description |
|-----------|-------------|
| Host | Adresse du serveur Trino |
| Port | Port Trino (défaut: 8080 ou 443 pour HTTPS) |
| Catalog | Catalog par défaut (optionnel) |
| Schema | Schema par défaut (optionnel) |
| SSL | Activer si HTTPS |

## Impersonation

Lorsque l'authentification **Username/Password** est utilisée, le connecteur :
1. Utilise `UID`/`PWD` pour l'authentification ODBC
2. Passe `DelegationUID` avec le username pour l'impersonation Trino

Trino verra les requêtes comme provenant de l'utilisateur spécifié.

## Structure du projet

```
TrinoConnector/
├── TrinoConnector.pq        # Code principal
├── TrinoConnector.query.pq  # Fichier de test
├── TrinoConnector.mproj     # Fichier projet
├── resources.resx           # Chaînes localisées
├── TrinoConnector*.png      # Icônes
└── .vscode/
    └── settings.json        # Configuration VS Code
```
